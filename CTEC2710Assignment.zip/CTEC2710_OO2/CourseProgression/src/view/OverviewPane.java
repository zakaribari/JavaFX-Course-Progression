
package view;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;

public class OverviewPane extends GridPane {

    private TextArea studentDetailsArea;
    private TextArea selectedModulesArea;
    private TextArea reservedModuleArea;
    private Button saveOverviewBtn;

    public OverviewPane() {

        this.setHgap(10);
        this.setVgap(10);
        this.setPadding(new Insets(15));

        // Student details
        Label studentDetailsLabel = new Label("Student Details:");
        studentDetailsArea = new TextArea();
        studentDetailsArea.setEditable(false);
        studentDetailsArea.setPrefRowCount(5);

        // Selected modules
        Label selectedModulesLabel = new Label("Selected Modules:");
        selectedModulesArea = new TextArea();
        selectedModulesArea.setEditable(false);
        selectedModulesArea.setPrefRowCount(8);

        // Reserved module
        Label reservedModuleLabel = new Label("Reserved Module:");
        reservedModuleArea = new TextArea();
        reservedModuleArea.setEditable(false);
        reservedModuleArea.setPrefRowCount(3);

        // Save button
        saveOverviewBtn = new Button("Save Overview");

        // Add components
        this.add(studentDetailsLabel, 0, 0);
        this.add(studentDetailsArea, 0, 1);

        this.add(selectedModulesLabel, 0, 2);
        this.add(selectedModulesArea, 0, 3);

        this.add(reservedModuleLabel, 0, 4);
        this.add(reservedModuleArea, 0, 5);

        this.add(saveOverviewBtn, 0, 6);
    }

    public TextArea getStudentDetailsArea() {
        return studentDetailsArea;
    }

    public TextArea getSelectedModulesArea() {
        return selectedModulesArea;
    }

    public TextArea getReservedModuleArea() {
        return reservedModuleArea;
    }

    public Button getSaveOverviewBtn() {
        return saveOverviewBtn;
    }
}

