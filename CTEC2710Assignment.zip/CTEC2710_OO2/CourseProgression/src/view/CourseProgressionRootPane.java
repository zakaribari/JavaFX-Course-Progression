
package view;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.layout.BorderPane;
import view.ReserveModulesPane;


public class CourseProgressionRootPane extends BorderPane {

    private InputStudentProfilePane ispp;
    private CourseProgressionMenuBar cpmb;
    private TabPane tp;
    private SelectModulesPane smp;
    private ReserveModulesPane rmp;
    private OverviewPane op;
    public CourseProgressionRootPane() {

        // Create tab pane and disable tabs from being closed
        tp = new TabPane();
        tp.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);

        // Create panes
        ispp = new InputStudentProfilePane();
        smp = new SelectModulesPane();
        rmp = new ReserveModulesPane();
        op = new OverviewPane();
        // Create tabs
        Tab t1 = new Tab("Input Profile", ispp);
        Tab t2 = new Tab("Select Modules", smp);
        Tab t3 = new Tab("Reserve Modules", rmp);
        Tab t4 = new Tab("Overview Details", op);
        tp.getTabs().addAll(t1, t2, t3,t4);

        // Create menu bar
        cpmb = new CourseProgressionMenuBar();

        // Add menu bar and tab pane to root pane
        this.setTop(cpmb);
        this.setCenter(tp);
    }

    // Methods allowing sub-containers to be accessed by the controller
    public InputStudentProfilePane getInputStudentProfilePane() {
        return ispp;
    }

    public SelectModulesPane getSelectModulesPane() {
        return smp;
    }

    public CourseProgressionMenuBar getCourseProgressionMenuBar() {
        return cpmb;
    }
public ReserveModulesPane getReserveModulesPane() {
	return rmp;
}
public OverviewPane getOverviewPane() {
	return op;
}
    // Method allowing the controller to change tabs
    public void changeTab(int index) {
        tp.getSelectionModel().select(index);
    }
}

