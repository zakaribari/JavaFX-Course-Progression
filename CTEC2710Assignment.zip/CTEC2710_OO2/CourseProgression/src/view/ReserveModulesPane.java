package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import model.Module;

public class ReserveModulesPane extends GridPane {
	
	private ListView<Module> unselectedList;
	private ListView<Module> reservedList;
	
	private Button btnAdd;
	private Button btnRemove;
	private Button btnReserve;
	
public ReserveModulesPane() {
	
	this.setVgap(15);
	this.setHgap(20);
	this.setAlignment(Pos.CENTER);
		unselectedList = new ListView<>();
		reservedList = new ListView<>();
		
		unselectedList.setPrefSize(350, 250);
		reservedList.setPrefSize(350, 250);
		
		btnAdd = new Button("Add");
		btnRemove = new Button("Remove");
		btnReserve = new Button("Reserve");
		
		
		unselectedList.setPrefSize(350, 250);
		reservedList.setPrefSize(350, 250);
		
		
		this.add(unselectedList, 0, 1);
		this.add(reservedList, 2, 1);
		
		this.add(btnAdd, 1, 1);
		this.add(btnRemove, 1, 2);
		this.add(btnReserve, 2, 2);

		this.add(new Label("Unselected Modules"), 0, 0);
		this.add(new Label("Reserved Module"), 2, 0);

}

			public ListView<Module> getUnselectedList(){
				return unselectedList;
			}
		public ListView<Module> getReservedList(){
			return reservedList;
		}
		
	public void addAddHandler(EventHandler<ActionEvent> handler) {
		btnAdd.setOnAction(handler);
	}	
	 public void addRemoveHandler(EventHandler<ActionEvent> handler) {
	        btnRemove.setOnAction(handler);
	    }

	
	public void addReserveHandler(EventHandler<ActionEvent> handler) {
		btnReserve.setOnAction(handler);
	}


	public void clearAllLists() {

	    unselectedList.getItems().clear();
	    reservedList.getItems().clear();

	}}	


