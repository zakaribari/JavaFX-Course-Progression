package view;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import model.Module;

public class SelectModulesPane extends GridPane{
	private ListView<Module> block1List;
    private ListView<Module> block2List;
    
    private ListView<Module> unselectedList;
    private ListView<Module> selectedList;

    private Button btnAdd;
    private Button btnRemove;
    private Button btnReset;
    private Button btnSubmit;

    private Label lblCredits;
	
    public SelectModulesPane() {
    	
    	this.setVgap(15);
    this.setHgap(20);
    this.setAlignment(Pos.CENTER);
    
    // create lists 
    block1List = new ListView<>();
    block2List = new ListView<>();
   
    unselectedList = new ListView<>();
    selectedList = new ListView<>();
    
    
    // create buttons
    btnAdd = new Button("Add");
    btnRemove = new Button("Remove");
    btnReset = new Button("Reset");
    btnSubmit = new Button("Submit");
    
    // create credits label
    lblCredits = new Label("Total Credits: 0");
    
    // set list sizes
    block1List.setPrefSize(300, 120);
    block2List.setPrefSize(300, 120);
    
    unselectedList.setPrefSize(300, 200);
    selectedList.setPrefSize(300, 200);
    
    // add headings
    this.add(new Label("Block 1 Compulsory"),0, 0);
    this.add(new Label("Block 2 Compulsory"),1, 0);
    //this.add(new Label("Block 3/4 Compulsory"),0 , 2);
    this.add(block1List, 0, 1);
    this.add(block2List, 1, 1);
    
    this.add(new Label("Unselected Modules"), 0, 2);
    this.add(new Label("Selected Modules"), 2, 2);
    
    this.add(unselectedList, 0, 3);
    this.add(btnAdd, 1, 3);
    this.add(btnRemove, 1, 4);
    this.add(selectedList, 2, 3);
    
    this.add(lblCredits, 0, 4);
    this.add(btnReset, 1, 5);
    this.add(btnSubmit, 2, 5);
    
    }

public ListView<Module> getBlock1List(){
	return block1List;
	
}

public ListView<Module>getBlock2List(){
	return block2List;
}
public ListView<Module> getUnselectedList(){
	return unselectedList;	
}
public ListView<Module> getSelectedList() {
return selectedList;
}

public void addAddHandler(EventHandler<ActionEvent> handler) {
    btnAdd.setOnAction(handler);
}

public void addRemoveHandler(EventHandler<ActionEvent> handler) {
    btnRemove.setOnAction(handler);
}
public void addResetHandler(EventHandler<ActionEvent> handler) {
	btnReset.setOnAction(handler);
}
public void addSubmitHandler(EventHandler<ActionEvent> handler) {
	btnSubmit.setOnAction(handler);

}
		public void updateCreditsLabel(int credits) {
			lblCredits.setText("Total creadits:" + credits);
		}

public void addsubmitHnadler(EventHandler<ActionEvent> handler) {
	btnSubmit.setOnAction(handler);
	
}



public void clearAllLists() {

    block1List.getItems().clear();
    block2List.getItems().clear();
    unselectedList.getItems().clear();
    selectedList.getItems().clear();

}



}




