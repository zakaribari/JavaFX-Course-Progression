package controller;
import view.ReserveModulesPane;
import javafx.event.ActionEvent;
import view.SelectModulesPane;
import javafx.event.EventHandler;
import model.Delivery;
import model.Course;
import model.Module;
import model.StudentProfile;
import view.CourseProgressionRootPane;
import view.InputStudentProfilePane;
import view.CourseProgressionMenuBar;
import java.time.LocalDate;
import model.Name;
import javafx.scene.control.Alert;
import view.OverviewPane;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import javafx.stage.FileChooser;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import javafx.stage.FileChooser;

/**
 * The CourseProgressionController connects the model and the view.
 * It handles user actions, manages student information,
 * controls module selection and reservation, and handles
 * saving and loading student data.
 */
public class CourseProgressionController {

	//fields to be used throughout class
	private StudentProfile model;
	private CourseProgressionRootPane view;
	
	private InputStudentProfilePane ispp;
	private CourseProgressionMenuBar cpmb;
	private SelectModulesPane smp;
	private ReserveModulesPane rmp;
	private OverviewPane op;
	/**
	 * Creates the controller and initialises the model and view.
	 * It also prepares the course data and connects the event handlers.
	 *
	 * @param model the StudentProfile model
	 * @param view the main application window
	 */
	
	public CourseProgressionController(StudentProfile model, CourseProgressionRootPane view) {
		//initialise model and view fields
		this.model = model;
		this.view = view;
		
		//initialise view subcontainer fields
		ispp = view.getInputStudentProfilePane();
		cpmb = view.getCourseProgressionMenuBar();
			smp = view.getSelectModulesPane();
			rmp = view.getReserveModulesPane();
			op  = view.getOverviewPane();
		//add courses to combobox within input student profile pane using the buildCourseData helper method below
		ispp.addCourseDataToComboBox(buildCourseData());

		//attach event handlers to view using private helper method
		this.attachEventHandlers();
	}
	/**
	 * Displays the modules for the selected course.
	 * Separates compulsory modules into their delivery blocks
	 * and places optional modules in the unselected list.
	 */
	
		private void populateModuleLists() {

    Course selectedCourse = model.getStudentCourse();

    if (selectedCourse == null) {
        return;
    }

    smp.getBlock1List().getItems().clear();
    smp.getBlock2List().getItems().clear();
    smp.getUnselectedList().getItems().clear();
    smp.getSelectedList().getItems().clear();

    model.clearSelectedModules();

    for (Module module : selectedCourse.getAllModulesOnCourse()) {

        if (module.isMandatory()) {

            if (module.getRunPlan() == Delivery.BLOCK_1) {
                smp.getBlock1List().getItems().add(module);

            } else if (module.getRunPlan() == Delivery.BLOCK_2) {
                smp.getBlock2List().getItems().add(module);

            } else if (module.getRunPlan() == Delivery.BLOCK_3_4) {
                smp.getSelectedList().getItems().add(module);
                model.addSelectedModule(module);
            }

        } else {
            smp.getUnselectedList().getItems().add(module);
        }
    }

    updateCredits();
}

	//helper method - used to attach event handlers
	private void attachEventHandlers() {
		//attach an event handler to the input student profile pane
		ispp.addInputStudentProfileHandler(new InputStudentProfileHandler());
		
	//attach an event handler to the menu bar that closes the application
		cpmb.addExitHandler(e -> System.exit(0));
		cpmb.addSaveHandler(new SaveStudentDataHandler());
		cpmb.addLoadHandler(new LoadStudentDataHandler());
	smp.addAddHandler(new AddModuleHandler());
	cpmb.addAboutHandler(e -> {

	    Alert alert = new Alert(Alert.AlertType.INFORMATION);

	    alert.setTitle("About");
	    alert.setHeaderText("Course Progression Application");
	    alert.setContentText(
	        "Course Progression System\n\n"
	        + "Developed as part of the Computer Science coursework.\n"
	        + "This application allows students to select modules "
	        + "and reserve modules."
	    );

	    alert.showAndWait();

	});
	smp.addRemoveHandler(new RemoveModuleHandler());
	smp.addSubmitHandler(new SubmitModuleHandler()); 
	smp.addResetHandler(new ResetModuleHandler());
	rmp.addAddHandler(new AddReserveModuleHandler());
	rmp.addRemoveHandler(new RemoveReserveModuleHandler());
	rmp.addReserveHandler(new ReserveModuleHandler());	
	op.getSaveOverviewBtn().setOnAction(new SaveOverviewHandler());	}

	
	private class InputStudentProfileHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			
			String pNumber = ispp.getStudentPnumber();

			Name studentName = ispp.getStudentName();

			String email = ispp.getStudentEmail();

			LocalDate date = ispp.getStudentDate();

			Course course = ispp.getSelectedCourse();
		
			if (pNumber.trim().isEmpty()
					||  studentName.getFirstName().trim().isEmpty()
					||  studentName.getFamilyName().trim().isEmpty()
					||  email.trim().isEmpty()
					||  date == null 
					||course == null) {
				Alert alert = new Alert (Alert.AlertType.ERROR);
			alert.setTitle("Input Error");
			alert.setHeaderText("Missing Information");
			alert.setContentText("Please complete all fields.");			alert.showAndWait();
			
			return;
			}
			
			// Save information in the model
			model.setStudentPnumber(pNumber.trim());
			
			model.setStudentName(studentName);
			
			model.setStudentEmail(email.trim());
			model.setSubmissionDate(date);
			model.setStudentCourse(course);
			//model.setStudentCourse(course);
			
			populateModuleLists();
			// Success message
			 Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("Success");
			alert.setHeaderText("Student Profile Saved");
			alert.setContentText("Student infromation has been saved successfully.");
			alert.showAndWait();
			
			}
		}
	

	
	/**
	 * Displays optional modules that have not been selected.
	 * These modules are available for the student to reserve.
	 */
			private void populateReserveList() {

				rmp.getUnselectedList().getItems().clear();
				rmp.getReservedList().getItems().clear();

				for (Module module : model.getStudentCourse().getAllModulesOnCourse()) {

        if (!module.isMandatory()) {

            if (!model.getAllSelectedModules().contains(module)) {
                rmp.getUnselectedList().getItems().add(module);
            }
        }
    }
}

	
	
	
	private class AddModuleHandler implements EventHandler<ActionEvent> {

	    public void handle(ActionEvent e) {

	        Module selectedModule =
	                smp.getUnselectedList().getSelectionModel().getSelectedItem();

	        if (selectedModule == null) {
	            return;
	        }

	        smp.getUnselectedList().getItems().remove(selectedModule);
	        smp.getSelectedList().getItems().add(selectedModule);

	        model.addSelectedModule(selectedModule);
	        updateCredits();
	    }
	}
	/**
	 * 
	 * 
	 * Removes an optional module from the selected list. Compulsory modules cannot be removed.
	 */
			private class RemoveModuleHandler implements EventHandler<ActionEvent> {

	    public void handle(ActionEvent e) {

	        Module selectedModule =
	                smp.getSelectedList().getSelectionModel().getSelectedItem();

	        if (selectedModule == null) {
	            return;
	        }

	        if (selectedModule.isMandatory()) {
	            return;
	        }

	        smp.getSelectedList().getItems().remove(selectedModule);
	        smp.getUnselectedList().getItems().add(selectedModule);

	        model.getAllSelectedModules().remove(selectedModule);
	        updateCredits();
	    }
	}

/**
 * Resets optional module selections while keeping compulsory modules.
 */
			
			private class ResetModuleHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        for (Module module : smp.getSelectedList().getItems()) {

            if (!module.isMandatory()) {
                smp.getUnselectedList().getItems().add(module);
            }
        }

        smp.getSelectedList().getItems().removeIf(
            module -> !module.isMandatory()
        );

        model.clearSelectedModules();

        for (Module module : smp.getSelectedList().getItems()) {
            model.addSelectedModule(module);
        }

        updateCredits();
    }
}
	

/**
 * Checks that the student has selected exactly 120 credits before submitting.
 */
			private class SubmitModuleHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        int totalCredits = 0;

        totalCredits += smp.getBlock1List().getItems().size() * 30;
        totalCredits += smp.getBlock2List().getItems().size() * 30;
        totalCredits += smp.getSelectedList().getItems().size() * 30;

        if (totalCredits != 120) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Credit Error");
            alert.setHeaderText("Incorrect Module Selection");
            alert.setContentText(
                "You must select exactly 120 credits. "
                + "Your current total is " + totalCredits + " credits."
            );

            alert.showAndWait();
            return;
        }

        // Populate the Reserve Modules tab
        populateReserveList();
        updateOverview();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Modules Submitted");
        alert.setContentText("You have successfully selected 120 credits.");

        alert.showAndWait();
    }
}
			
			/**
			 * Moves an available optional module into the reserved list.
			 */
		private class AddReserveModuleHandler implements EventHandler<ActionEvent>{
			public void handle(ActionEvent e) {
			Module SelectedModule =
					rmp.getUnselectedList().getSelectionModel().getSelectedItem();
			if (SelectedModule == null) {
				return;
				
			}
			rmp.getUnselectedList().getItems().remove(SelectedModule);
			
			rmp.getReservedList().getItems().add(SelectedModule);
			
			
			}
			
			}
		
		/**
		 * Removes a module from the reserved list.
		 */
			private class RemoveReserveModuleHandler implements EventHandler<ActionEvent>{
				public void handle(ActionEvent e) {
					Module selectedModule =
							rmp.getReservedList().getSelectionModel().getSelectedItem();
					if (selectedModule == null) {
						return;
		
					}
				rmp.getReservedList().getItems().remove(selectedModule);
				rmp.getUnselectedList().getItems().add(selectedModule);
				
				}
			}
			
/**
 * Saves the selected reserve module in the student profile.
 */
private class ReserveModuleHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        Module selectedModule =
                rmp.getReservedList().getSelectionModel().getSelectedItem();

        if (selectedModule == null) {
            return;
        }
        if (selectedModule == null) {
            return;
        }

        model.clearReservedModules();

        model.addReservedModule(selectedModule);
        updateOverview();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Reserve Module Saved");
        alert.setContentText(
                selectedModule.getModuleCode() + " has been saved as your reserve module."
        );
        alert.showAndWait();
    }
}
private void updateCredits() {

    int credits = 0;

    credits += smp.getBlock1List().getItems().size() * 30;
    credits += smp.getBlock2List().getItems().size() * 30;
    credits += smp.getSelectedList().getItems().size() * 30;

    smp.updateCreditsLabel(credits);
}

private void updateOverview() {

    // 1. Display student details
    String studentDetails = "";

    studentDetails += "P Number: " + model.getStudentPnumber() + "\n";
    studentDetails += "Full Name: " + model.getStudentName().getFullName() + "\n";
    studentDetails += "Email: " + model.getStudentEmail() + "\n";
    studentDetails += "Submission Date: " + model.getSubmissionDate() + "\n";

    if (model.getStudentCourse() != null) {
        studentDetails += "Course: "
                + model.getStudentCourse().getCourseName();
    }

    op.getStudentDetailsArea().setText(studentDetails);


    // 2. Display selected modules
    String selectedModules = "";

    for (Module module : model.getAllSelectedModules()) {

        selectedModules += module.toString() + " - "
                + module.getModuleCredits() + " credits\n";
    }

    op.getSelectedModulesArea().setText(selectedModules);


    // 3. Display reserved module
    String reservedModule = "";

    if (model.getAllReservedModules().isEmpty()) {

        reservedModule = "No reserve module selected.";

    } else {

        for (Module module : model.getAllReservedModules()) {

            reservedModule += module.toString() + " - "
                    + module.getModuleCredits() + " credits\n";
        }
    }

    op.getReservedModuleArea().setText(reservedModule);
}
/**
 * Saves the overview information into a text file.
 */
private class SaveOverviewHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        FileChooser fileChooser = new FileChooser();

        fileChooser.setTitle("Save Student Overview");

        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Text Files", "*.txt")
        );

        File file = fileChooser.showSaveDialog(view.getScene().getWindow());

        if (file == null) {
            return;
        }

        try (PrintWriter writer = new PrintWriter(file)) {

            writer.println("STUDENT OVERVIEW");
            writer.println("================");

            writer.println("\nSTUDENT DETAILS");
            writer.println(op.getStudentDetailsArea().getText());

            writer.println("\nSELECTED MODULES");
            writer.println(op.getSelectedModulesArea().getText());

            writer.println("\nRESERVED MODULE");
            writer.println(op.getReservedModuleArea().getText());

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Overview Saved");
            alert.setContentText("Your overview has been saved successfully.");
            alert.showAndWait();

        } catch (FileNotFoundException ex) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Save Error");
            alert.setHeaderText("Unable to Save File");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }
    }
}

/**
 * Saves the complete student profile using object serialization.
 * 
 */
private class SaveStudentDataHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        FileChooser fileChooser = new FileChooser();

        fileChooser.setTitle("Save Student Data");

        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Data Files", "*.dat")
        );

        File file = fileChooser.showSaveDialog(view.getScene().getWindow());

        if (file == null) {
            return;
        }

        try (ObjectOutputStream output = new ObjectOutputStream(
                new FileOutputStream(file))) {

            output.writeObject(model);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Student Data Saved");
            alert.setContentText("Student data saved successfully.");
            alert.showAndWait();

        } catch (IOException ex) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Save Error");
            alert.setHeaderText("Unable to Save Student Data");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }
    }
}

/**
 * Loads previously saved student data and restores the application interface.
 */
private class LoadStudentDataHandler implements EventHandler<ActionEvent> {

    public void handle(ActionEvent e) {

        FileChooser fileChooser = new FileChooser();

        fileChooser.setTitle("Load Student Data");

        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Data Files", "*.dat")
        );

        File file = fileChooser.showOpenDialog(view.getScene().getWindow());

        if (file == null) {
            return;
        }

        try (ObjectInputStream input = new ObjectInputStream(
                new FileInputStream(file))) {

            model = (StudentProfile) input.readObject();

            // Restore student profile
            ispp.loadStudentProfile(
                model.getStudentPnumber(),
                model.getStudentName(),
                model.getStudentEmail(),
                model.getSubmissionDate(),
                model.getStudentCourse()
            );

            // Clear old module lists
            smp.clearAllLists();
            rmp.clearAllLists();

            // Restore compulsory and optional modules
            for (Module module : model.getStudentCourse().getAllModulesOnCourse()) {

                if (module.isMandatory()) {

                    if (module.getRunPlan() == Delivery.BLOCK_1) {
                        smp.getBlock1List().getItems().add(module);

                    } else if (module.getRunPlan() == Delivery.BLOCK_2) {
                        smp.getBlock2List().getItems().add(module);

                    } else {
                        smp.getSelectedList().getItems().add(module);
                    }

                } else if (model.getAllSelectedModules().contains(module)) {

                    smp.getSelectedList().getItems().add(module);

                } else {

                    smp.getUnselectedList().getItems().add(module);
                }
            }

            // Restore reserve module lists
            for (Module module : model.getStudentCourse().getAllModulesOnCourse()) {

                if (!module.isMandatory()
                        && !model.getAllSelectedModules().contains(module)) {

                    if (model.getAllReservedModules().contains(module)) {
                        rmp.getReservedList().getItems().add(module);
                    } else {
                        rmp.getUnselectedList().getItems().add(module);
                    }
                }
            }

            updateCredits();
            updateOverview();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Student Data Loaded");
            alert.setContentText("Student data loaded successfully.");
            alert.showAndWait();

        } catch (IOException | ClassNotFoundException ex) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Load Error");
            alert.setHeaderText("Unable to Load Student Data");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }
    }
}
	//helper method - builds modules and course data and returns courses within an array
	private Course[] buildCourseData() {
		
		Module ctec3702 = new Module("CTEC3702", "Big Data and Machine Learning", 30, true, Delivery.BLOCK_1);
		Module ctec3703 = new Module("CTEC3703", "Mobile App Development and Big Data", 30, true, Delivery.BLOCK_1);

		Module ctec3701 = new Module("CTEC3701", "Software Development: Methods & Standards", 30, true, Delivery.BLOCK_2);

		Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Delivery.BLOCK_3_4);

		Module ctec3704 = new Module("CTEC3704", "Functional Programming", 30, false, Delivery.BLOCK_3_4);
		Module ctec3705 = new Module("CTEC3705", "Advanced Web Development", 30, false, Delivery.BLOCK_3_4);

		Module imat3711 = new Module("IMAT3711", "Privacy and Data Protection", 30, false, Delivery.BLOCK_3_4);
		Module imat3722 = new Module("IMAT3722", "Fuzzy Logic and Inference Systems", 30, false, Delivery.BLOCK_3_4);

		Module ctec3706 = new Module("CTEC3706", "Embedded Systems and IoT", 30, false, Delivery.BLOCK_3_4);


		Course compSci = new Course("Computer Science");
		compSci.addModule(ctec3702);
		compSci.addModule(ctec3701);
		compSci.addModule(ctec3451);
		compSci.addModule(ctec3704);
		compSci.addModule(ctec3705);
		compSci.addModule(imat3711);
		compSci.addModule(imat3722);

		Course softEng = new Course("Software Engineering");
		softEng.addModule(ctec3703);
		softEng.addModule(ctec3701);
		softEng.addModule(ctec3451);
		softEng.addModule(ctec3704);
		softEng.addModule(ctec3705);
		softEng.addModule(ctec3706);

		Course[] courses = new Course[2];
		courses[0] = compSci;
		courses[1] = softEng;

		return courses;
	}

}
