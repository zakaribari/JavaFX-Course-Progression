package model;

public enum Delivery {
	BLOCK_1, BLOCK_2, BLOCK_3_4
}
